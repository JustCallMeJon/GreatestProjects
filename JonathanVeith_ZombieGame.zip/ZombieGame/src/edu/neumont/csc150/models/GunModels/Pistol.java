package edu.neumont.csc150.models.GunModels;

public class Pistol extends Gun{

    public Pistol(){
        super(75, 75, 15, 15,20, 85, "Glock 19", AmmoType.NINE_MM);
    }


    @Override
    public int shoot(boolean forSelf) {
        if(!forSelf){
            int shotHit = RAND.nextInt(100)+1;
            if (getCurrentMagAmmoCount() >0){
                setCurrentMagAmmoCount(getCurrentMagAmmoCount() - 1);
                if(shotHit < getAccuracy()){
                    System.out.println("The pistol bullet hit!");
                    return getDamage();
                }else{
                    System.out.println("The pistol bullet missed.");
                    return 0;
                }
            }else{
                System.out.println("Click! The gun's empty.");
            }
        }else{
            if(getCurrentMagAmmoCount() > 0){
                System.out.println("BLAM! The " + ammoType.getDisplayName() + " splatters your brains out the left side" +
                        " of your head. \n You will be zombie food.");
            }else{
                System.out.println("Click! The gun's empty.");
                return -1;

            }
        }

        return 0;
    }


    @Override
    public String toString() {
        return getName() + " {" +
                "Ammo Type: " + ammoType +
                ", Current Ammo Left: " + getAmmoCount() +
                ", Maximum Ammo: " + getMAX_AMMO() +
                ", Number of rounds left in magazine: " + getCurrentMagAmmoCount()+
                ", Rounds Per Magazine: " + getMAX_AMMO() +
                ", Damage: " + getDamage() +
                ", Accuracy: " + getAccuracy() +
                '}';
    }
}
