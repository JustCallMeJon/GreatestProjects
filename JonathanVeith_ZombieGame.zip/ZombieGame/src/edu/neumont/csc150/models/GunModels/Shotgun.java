package edu.neumont.csc150.models.GunModels;

public class Shotgun extends Gun{
    private final int PELLETS = 8;
    private String shotgunAmmoAmount = "Number of rounds left in the tube: " + (getCurrentMagAmmoCount() - 1)+ ", with one in the chamber.";

    public Shotgun() {
        super(32,32,6, 6, 10, 60, "Mossberg 590", AmmoType.TWELVE_GAUGE);
    }

    private String getShotgunAmmoAmount() {
        return shotgunAmmoAmount;
    }

    private void setShotgunAmmoAmount(String shotgunAmmoAmount) {
        this.shotgunAmmoAmount = shotgunAmmoAmount;
    }
    @Override
    public int shoot(boolean forSelf) {
        if (!forSelf) {
            String[] numberToWords = {
                    "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight"
            };
            int hitCount = 0;
            if (getCurrentMagAmmoCount() >0){
                setCurrentMagAmmoCount(getCurrentMagAmmoCount() - 1);
                for (int i = 0; i < PELLETS; i++) {
                    int shotHit = RAND.nextInt(100)+1;
                    if(shotHit < getAccuracy()) {
                        hitCount++;
                    }
                }
                String hitText = numberToWords[hitCount];
                String missText = numberToWords[PELLETS-hitCount];
                if (hitCount == 0){
                    System.out.println("None of the pellets connected.");
                }else if (hitCount == 1){
                    System.out.println("A single pellet connected. The rest missed.");
                } else if (hitCount <= 7) {
                    System.out.println(hitText + " pellets connected. " + missText + " missed.");
                }else{
                    System.out.println("All pellets connect.");
                }
                shotgunLoadText();
            }else{
                System.out.println("Click! The gun's empty.");
            }
            return hitCount * getDamage();
        }else{
            if (getCurrentMagAmmoCount() >0){
                System.out.println("BLAM! The " + ammoType.getDisplayName() + " splatters your brains into the air, as" +
                        " your lifeless body slumps to the ground.\n You will be zombie food.");
            }else{
                System.out.println("Click! The gun's empty.");
                return -1;
            }
        }
        return 0;
    }

    public void shotgunLoadText(){
        if (getCurrentMagAmmoCount() >0){
            setShotgunAmmoAmount("Number of rounds left in the tube: " + (getCurrentMagAmmoCount() - 1)+ ", with one in the chamber.");
        } else{
            setShotgunAmmoAmount("Number of rounds left in the tube: " + (getCurrentMagAmmoCount())+ ", with nothing in the chamber.");
        }
    }

    @Override
    public void reload() {
        if (getCurrentMagAmmoCount() >0){
            if (getCurrentMagAmmoCount() == MAG_SIZE){
                System.out.println("There's no reason to reload the " + getName() + ". Action refunded");
            } else{
                int shellsToLoad = Math.min(3, Math.min(MAG_SIZE - getCurrentMagAmmoCount(), getAmmoCount()));
                setAmmoCount(getAmmoCount() - shellsToLoad);
                setCurrentMagAmmoCount(getCurrentMagAmmoCount() + shellsToLoad);
                shotgunLoadText();
                System.out.println(shotgunAmmoAmount);
            }
        }else{
            System.out.println("You don't have any more shells.");
        }

    }

    @Override
    public String toString() {
        return getName() + "{" +
                "Ammo Type: " + ammoType +
                ", Current Ammo Left: " + getAmmoCount() +
                ", Maximum Ammo: " + getMAX_AMMO() +
                ", Rounds Per Tube: " + (MAG_SIZE - 1) + ", with 1 in the chamber. "+
                "\n" + getShotgunAmmoAmount() +
                " Rounds Per Magazine: " + getMAX_AMMO() +
                ", Damage: " + getDamage() +
                ", Accuracy: " + getAccuracy() +
                '}';
    }
}
