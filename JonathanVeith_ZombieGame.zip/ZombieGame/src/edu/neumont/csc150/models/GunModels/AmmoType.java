package edu.neumont.csc150.models.GunModels;

public enum AmmoType {
    NINE_MM("9mm"),
    FORTY_FIVE_ACP("45 ACP"),
    TWELVE_GAUGE("12 Gauge"),
    FIVE_FIVE_SIX("5.56 NATO");
    private final String displayName;

    AmmoType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
