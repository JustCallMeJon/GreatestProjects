package edu.neumont.csc150.models.GunModels;

public class BurstRifle extends Gun{
    public BurstRifle() {
        super(120, 120, 30, 30, 25, 90, "M16A2" ,AmmoType.FIVE_FIVE_SIX);
    }

    @Override
    public int shoot(boolean forSelf) {
        if(!forSelf) {
            int hitCount = 0;
            if (getCurrentMagAmmoCount() >0){
                for (int i = 0; i < 3; i++) {
                    int shotHit = RAND.nextInt(100)+1;
                    setCurrentMagAmmoCount(getCurrentMagAmmoCount() - 1);
                    if(shotHit < getAccuracy()) {
                        hitCount++;
                    }
                }
                if (hitCount == 0){
                    System.out.println("None of the rounds connected.");
                }else if (hitCount == 1){
                    System.out.println("A single round connected. The rest missed.");
                } else if (hitCount == 2) {
                    System.out.println("Two rounds connected. One missed.");
                }else{
                    System.out.println("All Three Rounds Connect.");
                }


            }else{
                System.out.println("Click! The gun's empty.");
            }
            return hitCount * damage;
        }else{
            if(getCurrentMagAmmoCount() > 0){
                System.out.println("BLUH BLUH BLAM! The 3 " + ammoType.getDisplayName() + " rounds create a sizable cavity in your head." +
                        " You will be zombie food.");
            }else{
                System.out.println("Click! The gun's empty.");
                return -1;

            }

        }
        return 0;
    }


    @Override
    public String toString() {
        return getName() + " {" +
                "Ammo Type: " + ammoType +
                ", Current Ammo Left: " + getAmmoCount() +
                ", Maximum Ammo: " + getMAX_AMMO() +
                ", Number of rounds left in magazine: " + getCurrentMagAmmoCount()+
                ", Rounds Per Magazine: " + getMAX_AMMO() +
                ", Damage: " + getDamage() +
                ", Accuracy: " + getAccuracy() +
                '}';
    }
}
