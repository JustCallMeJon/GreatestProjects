package edu.neumont.csc150.models.GunModels;

import java.util.Random;

public abstract class Gun {
    public static final Random RAND = new Random();
    protected AmmoType ammoType;
    protected int ammoCount;
    protected final int MAX_AMMO;
    protected final int MAG_SIZE;
    protected int currentMagAmmoCount;
    protected int damage;
    protected int accuracy;
    protected String name;

    public Gun(int ammoCount, int MAX_AMMO, int MAG_SIZE, int currentMagAmmoCount, int damage, int accuracy, String name, AmmoType ammoType) {
        this.ammoCount = ammoCount;
        this.ammoType = ammoType;
        this.MAX_AMMO = MAX_AMMO;
        this.MAG_SIZE = MAG_SIZE;
        this.currentMagAmmoCount = currentMagAmmoCount;
        this.damage = damage;
        this.accuracy = accuracy;
        this.name = name;
    }

    public int getAmmoCount() {
        return ammoCount;
    }

    protected void setAmmoCount(int ammoCount) {
        this.ammoCount = ammoCount;
    }

    public int getDamage() {
        return damage;
    }

    protected void setDamage(int damage) {
        this.damage = damage;
    }

    public int getAccuracy() {
        return accuracy;
    }

    protected void setAccuracy(int accuracy) {
        this.accuracy = accuracy;
    }

    public int getMAX_AMMO() {
        return MAX_AMMO;
    }

    public int getMAG_SIZE() {
        return MAG_SIZE;
    }

    public int getCurrentMagAmmoCount() {
        return currentMagAmmoCount;
    }

    protected void setCurrentMagAmmoCount(int currentMagAmmoCount) {
        this.currentMagAmmoCount = currentMagAmmoCount;
    }

    public String getName() {
        return name;
    }

    protected void setName(String name) {
        this.name = name;
    }

    public abstract int shoot(boolean forSelf);

    public void reload() {
        if (getCurrentMagAmmoCount() >0){
            if (getCurrentMagAmmoCount() == MAG_SIZE){
                System.out.println("There's no reason to reload the " + getName() + ". Action refunded");
            } else{
                setAmmoCount(getAmmoCount() - (MAG_SIZE - getCurrentMagAmmoCount()));
                setCurrentMagAmmoCount(getMAG_SIZE());
                System.out.println(getName() + " reloaded!");
            }
        }else{
            System.out.println("You don't have any more rounds.");
        }
    }
}
