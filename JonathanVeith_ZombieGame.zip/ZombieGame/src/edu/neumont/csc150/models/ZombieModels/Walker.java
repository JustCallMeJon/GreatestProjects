package edu.neumont.csc150.models.ZombieModels;

import edu.neumont.csc150.models.Player;

public class Walker extends Zombie {
    private static int walkerCount = 1;

    public Walker(Player player) {
        super(walkerCount++);
        setDistance();
        setSpeed(RANDOM.nextInt(10 - 2 + 1) + 2);
        setBaseHP(RANDOM.nextInt(60 - 30 + 1) + 30);
        setMaxHP(getBaseHP());
        setHitDamage(RANDOM.nextInt(10) + 1);
        setMoneyDropped(RANDOM.nextInt(10) + 20);
        setDifPointCost(1);
    }



    @Override
    public String simpleToString() {
        return super.toString();
    }



    @Override
    public String toString() {
        return super.toString() + "{ " +
                "\n damage: " + getHitDamage() +
                "\n Distance from the base: " + getDistance() +
                "\n Speed: " + getSpeed() +
                "\n Health: " + getBaseHP() + "/" + getMaxHP() +
                '}';
    }
}
