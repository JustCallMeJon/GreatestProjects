package edu.neumont.csc150.models.ZombieModels;

import edu.neumont.csc150.models.Player;

public class Runner extends Zombie {
    private static int runnerCount = 1;

    public Runner(Player player) {
        super(runnerCount++);
        setDistance();
        setSpeed(RANDOM.nextInt(15 - 5 + 1) + 5);
        setBaseHP(RANDOM.nextInt(40 - 20 + 1) + 20);
        setMaxHP(getBaseHP());
        setHitDamage(RANDOM.nextInt(5) + 1);
        setMoneyDropped(RANDOM.nextInt(5) + 30);
        setDifPointCost(2);
    }


    @Override
    public String simpleToString() {
        return super.toString();
    }

    @Override
    public String toString() {
        return super.toString() + "{ " +
                "\n damage: " + getHitDamage() +
                "\n Distance from the base: " + getDistance() +
                "\n Speed: " + getSpeed() +
                "\n Health: " + getBaseHP() + "/" + getMaxHP() +
                '}';
    }
}
