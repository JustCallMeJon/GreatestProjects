package edu.neumont.csc150.models.ZombieModels;

import edu.neumont.csc150.models.Player;

import java.util.Random;

public abstract class Zombie {
    private final int id;
    private int baseHP;
    private int maxHP;
    private int speed;
    private int hitDamage;
    private int distance;
    private int moneyDropped;
    private int difPointCost;
    public static final Random RANDOM = new Random();
    protected Player player;

    public Zombie(Player player) {
        this.player = player;
        id = 0;
    }


    protected Zombie(int i) {
        this.id = i;
    }

    public int getId() {
        return id;
    }


    public int getBaseHP() {
         return baseHP;
    }

    protected void setBaseHP(int baseHP) {
        this.baseHP = baseHP;
    }

    public int getMaxHP() {
        return maxHP;
    }

    protected void setMaxHP(int maxHP) {
        this.maxHP = maxHP;
    }

    public int getSpeed() {
        return speed;
    }

    protected void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getHitDamage() {
        return hitDamage;
    }

    protected void setHitDamage(int hitDamage) {
        this.hitDamage = hitDamage;
    }

    public int getDistance() {
        return distance;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public Player getPlayer() {
        return this.player;
    }

    protected void setDistance() {
        this.distance = 100;
    }

    public int getMoneyDropped() {
        return moneyDropped;
    }

    protected void setMoneyDropped(int moneyDropped) {
        this.moneyDropped = moneyDropped;
    }

    public int getDifPointCost() {
        return difPointCost;
    }

    protected void setDifPointCost(int difPointCost) {
        this.difPointCost = difPointCost;
    }


    protected void setDistance(int distance) {
        this.distance = distance;
    }


    public void attack(Zombie zombie) {
        if (getDistance() >= 0) {
            move(zombie);
        }
        if(getDistance() == 0){
            player.takeDamage(getHitDamage());
        }
    }
    public int move(Zombie zombie) {
        zombie.setDistance(zombie.getDistance() - zombie.getSpeed());
        if (getDistance() < 0) {
            zombie.setDistance(0);
        }
        return 0;
    }
    public int takeDamage(int damage) {
        this.setBaseHP(Math.max(0,(getBaseHP() - damage)));
        return getBaseHP();
    }
    public abstract String simpleToString();

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + " #" + getId();
    }

}
