package edu.neumont.csc150.models.ZombieModels;

import edu.neumont.csc150.models.Player;

public class Tank extends Zombie {
    private static int tankCount = 1;
    private float damageMultiplier;

    private float getDamageMultiplier() {
        return damageMultiplier;
    }

    private void setDamageMultiplier(float damageMultiplier) {
        this.damageMultiplier = damageMultiplier;
    }

    public Tank(Player player) {
        super(tankCount++);
        setDistance();
        setDamageMultiplier((RANDOM.nextInt(5) + 5) / 10f);
        setSpeed(RANDOM.nextInt(5 - 2 + 1) + 2);
        setBaseHP(RANDOM.nextInt(150 - 75 + 1) + 75);
        setMaxHP(getBaseHP());
        setHitDamage((int) (RANDOM.nextInt((11) + 10) * (1.5 + getDamageMultiplier())));
        setMoneyDropped(RANDOM.nextInt(10) + 40);
        setDifPointCost(5);
    }


    @Override
    public String simpleToString() {
        return super.toString();
    }

    @Override
    public String toString() {
        return super.toString() + "{ " +
                "\n damage: " + getHitDamage() +
                "\n Distance from the base: " + getDistance() +
                "\n Speed: " + getSpeed() +
                "\n Health: " + getBaseHP() + "/" + getMaxHP() +
                "\n Damage Multiplier: " + getDamageMultiplier() +
                '}';
    }
}
