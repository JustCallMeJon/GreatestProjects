package edu.neumont.csc150.models;

import edu.neumont.csc150.controller.NoHealthException;

public class Player {
    private final int MAX_HP = 100;
    private int currentHP = 100;
    private int money;
    private int kills;




    public int getCurrentHP() {
        return currentHP;
    }

    public void setCurrentHP(int currentHP) {
        this.currentHP = currentHP;
    }

    public int getMAX_HP() {
        return MAX_HP;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public int getKills() {
        return kills;
    }

    public void setKills(int kills) {
        this.kills = kills;
    }

    public void takeDamage(int damage) {
        setCurrentHP(getCurrentHP() - damage);
        System.out.println("You took " + damage + " damage!");
        if (currentHP <= 0) {
            throw new NoHealthException("You have no more health!");
        }
    }

    @Override
    public String toString() {
        return "Player{" +
                "MAX_HP=" + getMAX_HP() +
                ", currentHP=" + getCurrentHP() +
                ", money=" + getMoney() +
                '}';
    }
}
