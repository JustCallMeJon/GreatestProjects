package edu.neumont.csc150.models;

public class Days {
    private int difficulty;
    private int difficultyPoints;
    private int days;

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        if (difficulty < 1 || difficulty > 5) {
            System.out.println("Invalid difficulty");
        }else{
            this.difficulty = difficulty;
        }
    }

    public int getDifficultyPoints() {
        return difficultyPoints;
    }

    public void setDifficultyPoints(int difficultyPoints) {
        this.difficultyPoints = difficultyPoints;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        if (days < 1){
            this.days = 1;
        }else{
            this.days = days;
        }
    }

    public int newDay(){
        return days++;
    }

        public void calculateZombieGen(int numDays, int difficulty){
         setDifficultyPoints(numDays * difficulty);
    }

}
