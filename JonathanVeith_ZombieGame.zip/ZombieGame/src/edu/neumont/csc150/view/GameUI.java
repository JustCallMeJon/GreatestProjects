package edu.neumont.csc150.view;

import edu.neumont.csc150.controller.GameController;
import edu.neumont.csc150.controller.PlayerKilledThemselvesException;
import edu.neumont.csc150.controller.NoHealthException;
import edu.neumont.csc150.models.Days;
import edu.neumont.csc150.models.Player;

import java.util.InputMismatchException;
import java.util.Scanner;

public class GameUI {
    private final GameController controller;
    private final Days days = new Days();
    private final Player player = new Player();

    public GameUI() {
        this.controller = new GameController(days, player);
    }

    public void playTheGame() {
        Scanner sc = new Scanner(System.in);
        boolean difficultySelected = false;
        boolean gameOver = false;
        controller.giveGuns();
        try {
            do {
                System.out.println("""
                        Select a difficulty:
                        1 - Trivial
                        2 - Easy
                        3 - Normal
                        4 - Hard
                        5 - Lethal
                        """);
                try {
                    int difficulty = Integer.parseInt(sc.nextLine());
                    switch (difficulty) {
                        case 1:
                            days.setDifficulty(1);
                            difficultySelected = true;
                            break;
                        case 2:
                            days.setDifficulty(2);
                            difficultySelected = true;
                            break;
                        case 3:
                            days.setDifficulty(3);
                            difficultySelected = true;
                            break;
                        case 4:
                            days.setDifficulty(4);
                            difficultySelected = true;
                            break;
                        case 5:
                            days.setDifficulty(5);
                            difficultySelected = true;
                            break;
                        default:
                            System.out.println("Invalid difficulty");
                            break;
                    }
                } catch (InputMismatchException | NumberFormatException e) {
                    System.out.println("Invalid input");
                }

            } while (!difficultySelected);


            System.out.println("The undead rise again. Chaos has broken out across the world.");
            System.out.println("These are the end times. There was no hope of survival. This was your final stand before you died.");
            controller.newDay();
            do {
                try {
                    System.out.println("Your health: " + player.getCurrentHP() + "/" + player.getMAX_HP());
                    System.out.println("""
                            The undead are coming. What will you do?
                            1: Inspect a Zombie?
                            2: Inspect all Zombies?
                            3: Inspect a gun?
                            4: Inspect all guns?
                            5: Shoot a Zombie? (Consumes your turn)
                            6: Reload a gun? (Consumes your turn)
                            7: Wait? (Consumes your turn)
                            8: End it all? 
                            """);
                    int choice = Integer.parseInt(sc.nextLine());
                    switch (choice) {
                        case 1:
                            controller.showSingleZombie();
                            break;
                        case 2:
                            controller.showZombies();
                            break;
                        case 3:
                            controller.showAGun();
                            break;
                        case 4:
                            controller.showGuns();
                            break;
                        case 5:
                            controller.chooseGun(1);
                            break;
                        case 6:
                            controller.chooseGun(2);
                            break;
                        case 7:
                            controller.passTurn();
                            break;
                        case 8:
                            controller.chooseGun(3);
                            break;
                        default:
                            System.out.println("Invalid choice");
                            break;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input");
                }

            } while (!gameOver);
        } catch (PlayerKilledThemselvesException e) {
            System.out.println("The game is over. You have killed yourself, and your last stand has ended by your hand.");
            controller.displayStats();
        }catch(NoHealthException e) {
            System.out.println("The game is over. You were torn to shreds by the undead horde.");
            controller.displayStats();
        }
    }
}

