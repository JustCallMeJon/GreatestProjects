package edu.neumont.csc150;

import edu.neumont.csc150.view.GameUI;

public class Main {
    //TODO: Verify that the code meets all the requirements before passing off.
    public static void main(String[] args) {
        new GameUI().playTheGame();
    }
}
