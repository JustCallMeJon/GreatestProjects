package edu.neumont.csc150.controller;

public class NoHealthException extends RuntimeException {
    public NoHealthException(String message) {
        super(message);
    }
}
