package edu.neumont.csc150.controller;

public class PlayerKilledThemselvesException extends RuntimeException {
    public PlayerKilledThemselvesException() {
        super("Game Over");
    }
}
