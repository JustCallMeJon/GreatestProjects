package edu.neumont.csc150.controller;

import edu.neumont.csc150.models.Days;
import edu.neumont.csc150.models.GunModels.BurstRifle;
import edu.neumont.csc150.models.GunModels.Gun;
import edu.neumont.csc150.models.GunModels.Pistol;
import edu.neumont.csc150.models.GunModels.Shotgun;
import edu.neumont.csc150.models.Player;
import edu.neumont.csc150.models.ZombieModels.Runner;
import edu.neumont.csc150.models.ZombieModels.Tank;
import edu.neumont.csc150.models.ZombieModels.Walker;
import edu.neumont.csc150.models.ZombieModels.Zombie;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class GameController {
    private final ArrayList<Zombie> zombies = new ArrayList<>();
    private final ArrayList<Gun> guns = new ArrayList<>();
    public static final Random RAND = new Random();
    private final Days days;
    private Player player;

    public GameController(Days days, Player player) {
        this.player = player;
        this.days = days;
    }


    // <editor-fold desc="Zombie Logic">

    public void generateZombie() {
        days.calculateZombieGen(days.getDays(), days.getDifficulty());
        int numberOfZombiesGenerated = days.getDifficultyPoints();
        do {
            int type = RAND.nextInt(3);
            Zombie zombieGuy = switch (type) {
                case 0 -> new Walker(this.player);
                case 1 -> new Runner(this.player);
                case 2 -> new Tank(this.player);
                default -> null;
            };
            if (zombieGuy != null && canMakeZombie(zombieGuy.getDifPointCost(), numberOfZombiesGenerated) == true) {
                zombieGuy.setPlayer(this.player);
                zombies.add(zombieGuy);
                numberOfZombiesGenerated -= zombieGuy.getDifPointCost();
            }


        } while (numberOfZombiesGenerated > 0);
    }

    public void showZombies() {
        for (Zombie zombie : zombies) {
            System.out.println(zombie);
        }
    }

    public void showZombieCount() {
        int walkers = 0, runners = 0, tanks = 0;
        for (Zombie zombie : zombies) {
            if (zombie instanceof Walker) {
                walkers++;
            } else if (zombie instanceof Runner) {
                runners++;
            } else if (zombie instanceof Tank) {
                tanks++;
            }
        }
        System.out.println("Number of walkers: " + walkers
                + "\nNumber of runners: " + runners
                + "\nNumber of tanks: " + tanks);
    }

    public void useZombies() {
        for (Zombie zombie : zombies) {
            zombie.attack(zombie);
        }
    }

    public void showSingleZombie() {
        System.out.println("Which Zombie do you wish to see?");
        for (int i = 0; i < zombies.size(); i++) {
            System.out.println((i + 1) + ": " + zombies.get(i).simpleToString());
        }
        Scanner scanner = new Scanner(System.in);

        int choice = 0;
        while (true) {
            System.out.println("\n Enter the number of the zombie you wish to see: ");
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine();
            }
            if (choice >= 1 && choice <= zombies.size()) {
                break;
            } else {
                scanner.nextLine();
            }
            System.out.println("Invalid option, try again.");
        }

        Zombie selectedZombie = zombies.get(choice - 1);
        System.out.println(selectedZombie.toString());

    }

    public void removeZombie(Zombie zombie) {
        zombies.remove(zombie);
    }

    public boolean canMakeZombie(int difPointCost, int difficultyPoints) {
        return difPointCost <= difficultyPoints;
    }

// </editor-fold>

    // <editor-fold desc="Gun Logic">
    public void giveGuns() {
        guns.add(new Pistol());
        guns.add(new Shotgun());
        guns.add(new BurstRifle());
    }

    public void showAGun() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Which gun would you like to see?");

        for (int i = 0; i < guns.size(); i++) {
            System.out.println((i + 1) + ": " + guns.get(i).getName());
        }

        int choice = Integer.parseInt(sc.nextLine());

        if (choice <= 0 || choice >= guns.size()) {
            System.out.println("Invalid choice, try again.");
            return;
        }
        System.out.println(guns.get(choice - 1).toString());
    }

    public void showGuns() {
        for (Gun gun : guns) {
            System.out.println(gun.toString());
        }
    }

    public void chooseGun(int actionRequested) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Which gun will you choose?");


        for (int i = 0; i < guns.size(); i++) {
            System.out.println((i + 1) + ": " + guns.get(i).getName());
        }

        int choice = Integer.parseInt(sc.nextLine());
        int gunChoice = choice;
        if (choice < 0 || (choice >= guns.size() + 1)) {
            System.out.println("Invalid choice, try again. Your action has been refunded.");
            return;
        }
        switch (choice) {
            case 1:
                gunChoice = 0;
                break;
            case 2:
                gunChoice = 1;
                break;
            case 3:
                gunChoice = 2;
                break;
            default:
                break;
        }

        switch (actionRequested) {
            case 1 -> shootGun(gunChoice);
            case 2 -> reloadGun(gunChoice);
            case 3 -> killYourself(gunChoice);

            default ->
                    System.out.println("Wait, what the...? How- what- uhh... Something went wrong with the chooseGun method... figure it out.");
        }
    }

    public void shootGun(int gunChoice) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("What zombie will you target?");
        for (int i = 0; i < zombies.size(); i++) {
            System.out.println((i + 1) + ": " + zombies.get(i).simpleToString());
        }
        int choice = (Integer.parseInt(scanner.nextLine()) - 1);
        if (choice < 0 || choice >= zombies.size()) {
            System.out.println("Invalid choice, try again.");
            return;
        }
        int damage = guns.get(gunChoice).shoot(false);
        System.out.println("Damage Dealt: " + damage);
        Zombie target = zombies.get(choice);
        String zombieName = zombies.get(choice).simpleToString();
        target.takeDamage(damage);
        if (zombies.get(choice).getBaseHP() == 0) {
            player.setMoney(player.getMoney() + zombies.get(choice).getMoneyDropped());
            zombies.remove(choice);
            player.setKills(player.getKills() + 1);
            System.out.println(zombieName + " was killed by your " + guns.get(gunChoice).getName());
        }
        if (zombies.size() == 0) {
            newDay();
        } else {
            useZombies();
        }

    }


    public void reloadGun(int gunChoice) {
        if (gunChoice >= 0 && gunChoice < guns.size()) {
            guns.get(gunChoice).reload();
        } else {
            System.out.println("Invalid gun chosen.");
        }
    }

    //</editor-fold>

    public void newDay() {
        days.setDays(days.getDays() + 1);
        generateZombie();
        System.out.println("Day: " + days.getDays());
        showZombieCount();
    }


    public void passTurn() {
        System.out.println("You wait for the undead to get closer...");
        useZombies();
    }

    public void killYourself(int gunChoice) {
        Scanner scanner = new Scanner(System.in);
        if (gunChoice == 0) {
            System.out.println("You put your " + guns.get(gunChoice).getName() + " to your right temple. You've " +
                    "seen too much. Are you sure this is how you want to end it?");
        } else if (gunChoice == 1 || gunChoice == 2) {
            System.out.println("You put your " + guns.get(gunChoice).getName() + " to the bottom of your chin. " +
                    "You've seen too much. Are you sure this is how you want to end it?");
        } else {
            System.out.println("Something in KYS went wrong...");
        }
        try {
            System.out.println("""
                    1: Yes
                    2: No
                    """);
            int choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1:
                    int success = guns.get(gunChoice).shoot(true);
                    if (success !=-1){
                        throw new PlayerKilledThemselvesException();
                    }else{
                        return;
                    }

                case 2:
                    return;
                default:
                    System.out.println("Invalid choice, try again.");
                    break;

            }
        }catch(IndexOutOfBoundsException e) {
            System.out.println("Invalid choice, try again.");
        }
    }
    public void displayStats(){
        System.out.println("Zombies killed: " + player.getKills());
        System.out.println("Money earned: " + player.getMoney());
    }
}